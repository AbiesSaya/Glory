# Glory SSH

一个简单的 SSH 远程管理工具，可以保存和管理多个 SSH 连接配置。

 -h for help
 -n for new server
 -c for connect server

